# Uniform bound for S(T), slope 0.0751

Certified without RH: |S(T)| <= 0.0751 log(T) + 16.58585760 for every T>1.
Preserve this entire PaperMath directory. The original prime binary is not
needed to reproduce the proof. Numerical search data are not accepted as proof.

Use the Python environment recorded in requirements-lock.txt, then run:

    python numerics/explicit_S_turing/optimization_C/additive_A0751_20261107/src/reproduce_certificate.py --slope 0.0751
    python numerics/explicit_S_turing/optimization_C/additive_A0751_20261107/src/audit_and_select.py

The first command creates a new proof execution directory. The second audits
the stored proof inputs and hashes, translating original absolute paths to
this repository root. Historical output files retain their original paths.

Read RESULTADO_CONSTANTE_ADITIVA.md and FINAL_RESULT.json in
numerics/explicit_S_turing/optimization_C/additive_A0751_20261107/.
The older slope work and original certificates are preserved as history.
The old 0.08382, 2.959227629 pair has a different slope. Do not mix the pairs.
No global optimality or RH proof is claimed.
