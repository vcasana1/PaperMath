# CONTINUACIÓN DE TRABAJO — CASTOR–POLLUX I (estado tras la v2)

**Fecha:** 10 de noviembre de 2026. Sustituye a `CONTINUACION_CASTOR_POLLUX.md` (estado de la v1).

## 1. Documento de referencia

| Versión | Archivo | SHA-256 | Líneas |
|---|---|---|---|
| v1 (intacta) | `Castor_Pollux_I_v1.tex` | `3bc78229172e068d3f4b5403e7ff808c565b7f6baa8694b8da2f4774f5f7556a` | 2 051 |
| **v2 (vigente)** | `Castor_Pollux_I_v2.tex` | `ecfae630f67a726a50bf3065d86cf5fe6a2047860738a113111a52e5b1f464b8` | 2 056 |

La v2 se obtiene de la v1 con `make_v2_from_v1.py` (24 sustituciones exactas en el cuerpo y 8 grupos en los tooltips; cada una debe casar una sola vez). El diff completo está en `diff_v1_to_v2.txt`. El bloque `CorrectVCG` embebido (v10) es idéntico byte a byte. Las 25 marcas `\VCGreviewed` no se han tocado.

Comprobador sobre la v2: `--paper` da 0 errores y 1 advertencia (la de `lem:T`, por patrón; el texto ya trata los dos signos). `--diff v1 --allowed allowed_labels_v2.txt` da 48 bloques cambiados, todos en la lista autorizada.

Compilación en directorio aislado con los ocho PNG: 4 pasadas de pdfLaTeX, 0 errores, 0 avisos de LaTeX, 0 referencias sin resolver, 22 páginas.

## 2. Bloque congelado

Sigue valiendo la tabla de la sección 3 del archivo de continuidad anterior. La v2 no cambia ningún enunciado ni ninguna demostración de esos bloques, salvo el cambio de letra del índice (`i` → `b`) y la frase añadida al final de la prueba de `lem:T`.

## 3. Incidencias de la v1 y su estado

| Incidencia | Estado en la v2 |
|---|---|
| **P0** Rouché sin cota de redondeo (l. 668–685) | **Cerrada.** `castor_pollux_I_rouche_certificate_v1.py`: aritmética de bolas Arb (python-flint 0.9.0, FLINT 3.6.0), 128 bits. Los seis discos certificados: cota superior del miembro izquierdo < cota inferior del derecho; razón izquierda/derecha entre 0.0452 y 0.4670; radios de Re/Im de η₀, η₁ < 2·10⁻³³. La tabla `tab:rouche` no cambia: sus entradas coinciden con las bolas redondeadas. El texto cita Arb (Johansson 2017, DOI comprobado). |
| **P1** `G/A` (l. 915–917, figura `fig:zeromap`) | **Corregida la redacción.** El cociente se forma solo donde `A≠0`; en la malla 39×157, `|A| ≥ 0.072` (`check_A_grid.py`). El emparejamiento de los seis arcos queda como observación numérica, en el texto y en el pie de figura. **Abierto:** `A≠0` en todo el rectángulo no está demostrado. |
| **P1** tabla `tab:check` (l. 882–899) | **Presentada como comprobación numérica.** Se dan los valores de la cota de la cola de integración en los cuatro casos (4.1·10⁻⁷, 1.5·10⁻⁷, 2.5·10⁻⁵, 1.4·10⁻⁴) y la diferencia observada (≤ 1.3·10⁻⁸). **Abierto:** sin cota para la cuadratura ni para la cola `r > 20000`. |
| **P2.1** «Seven figures» | Corregido: «Eight figures». |
| **P2.2** alcance de las técnicas (abstract) | Corregido: se nombran Cauchy–Schwarz, Rouché y análisis real y complejo estándar. |
| **P2.3** choque de `i` | Corregido: `i` es solo la unidad imaginaria; el índice entero pasa a `b` en 11 pasajes del cuerpo (nodos `x_b`, `cor:angular`, `J_2`, `har`, `cor:partial`, `prop:bound`), en la tabla de símbolos (con fila nueva para `i`) y en los tooltips. |
| **P2.4** caso `r' < 0` en `lem:T` | Añadida la frase: numerador y denominador cambian de signo a la vez, y `T_{jk}(r) > 0`. |
| **P2.5** tooltips | `in t_` → `int_` en 46 apariciones y `=()frac` → `=frac` en 4. El resto de los textos automáticos no se ha tocado. |
| **P1** paquete compilable | **Cerrada.** El zip de la v2 lleva los ocho PNG con sus nombres exactos, los scripts que los generan y sus salidas. |

## 4. Hallazgos nuevos, no corregidos (no estaban en la lista)

1. **Choque de `a`**: es `j∨k` en la sección del peso potencial, el exponente en `p^a` (párrafo de `J_2`) y los números `a_b ∈ [0,1]` (prueba de `cor:partial`).
2. **Línea 557**: los momentos `H(1/2)`, `H'(1/2)`, `H''(1/2)`, `V(1/2)` siguen calculados en doble precisión (`castor_numerics.py`); el certificado por bolas cubre solo la tabla `tab:rouche`.
3. **«`|G−A| < 10⁻¹¹` en los seis puntos»** (sección de figuras): ningún script del paquete produce ese número; `figures.py` evalúa `G` con error ~10⁻⁷.
4. La cota `(π²/6)[j,k]X^{-2σ-1}` «aplicada en la cola» usa la prueba de `prop:bound` con otro extremo inferior; el enunciado de la proposición es para `a = j∨k`.

## 5. Trabajo paralelo (chat «Demostración de RH desde el md y tex»)

Datos comunicados por ese chat, no recalculados aquí:

- GitHub: `vcasana1/papermath`, rama `castor-pollux-zeros`, carpeta `castor_pollux_zeros/` (no en `main`).
- `G`: 79 ceros con `0.2 ≤ Im s ≤ 200`, todos con `0.1037 ≤ Re s ≤ 1.1274`; recuento por principio del argumento 79.
- `A`: ningún cero complejo en `-60 ≤ Re s ≤ 201`, `0 < Im s ≤ 200`; ceros reales en `-2`, `-1` y uno en cada `(2k, 2k+2)`.
- Derivación a mano, sin comprobar, de `G − A` en `-2 < σ < 0` como identidad; prevista para un «Pollux II», no para esta nota.

Lo de `A` es coherente con la v2: aquí el número de vueltas de `A` en el borde del rectángulo de las figuras sale 0 (cálculo en doble precisión, no incluido en el texto).

## 6. Pendiente

- **GitHub:** nada de este chat está subido. La petición de acceso de escritura a `vcasana1/PaperMath` fue denegada en esta sesión. Para no chocar con la otra rama, lo natural es una carpeta propia (por ejemplo `castor_pollux_I/`) con el certificado de Rouché y sus salidas.
- Decidir si se corrigen los puntos de la sección 4.
- Si se quiere cerrar del todo `tab:check`: cota para la cola `r > 20000` y para la cuadratura, o cálculo por intervalos de los dos miembros.

## 7. Protocolo

Igual que en la versión anterior: comprobar el SHA-256 de la v2 antes de reutilizar este estado; trabajar solo sobre incidencias abiertas; no crear versiones nuevas sin orden; cada versión nueva lleva número nuevo y su `.txt`.
