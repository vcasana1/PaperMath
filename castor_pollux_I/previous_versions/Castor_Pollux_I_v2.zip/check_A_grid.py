# Castor-Pollux I v2: the quotient G/A of Figure fig:zeromap is formed on the 39 x 157 grid of figures.py.
# This script reads grid_values.npz (written by figures.py) and prints the smallest computed |A(s)| on that grid.
import numpy as np
d = np.load('grid_values.npz', allow_pickle=False)
A, G, sig, t = d['A'], d['G'], d['sigma'], d['t']
k = np.unravel_index(np.abs(A).argmin(), A.shape)
print("grid:", A.shape, " (Im s) x (Re s)")
print("min |A(s)| on the grid = %.10f  at s = %.2f + %.2f i" % (np.abs(A).min(), sig[k[1]], t[k[0]]))
print("max |A(s)| on the grid = %.10f" % np.abs(A).max())
print("max |G(s)/A(s)| on the grid = %.10f" % np.abs(G/A).max())
