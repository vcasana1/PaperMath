COMPLETE V8 MANUSCRIPT
The PDF is built from the TEX in this ZIP.
The TXT is a byte-identical copy of the TEX.
Both stored Green-Jensen certificate ZIPs have independently checked SHA-256 hashes.
No improvement in the proportion of critical-line zeros is asserted.
