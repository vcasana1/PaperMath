import datetime,json
from pathlib import Path
r=Path('/Users/vcasana/PaperMath-repro-kernels-2026-11-01');e=r/'evidence_kernels_hybrid_2026-11-01'
if not (e/'state.json').exists():print('not started');raise SystemExit
d=json.loads((e/'state.json').read_text())
print(datetime.datetime.now().isoformat(),d['phase'],'VERIFIED',sum(x['status']=='CONFORME' for x in d['results'].values()),'INCIDENTS',d['incidents'])
for rel,row in d['results'].items():
    if row['status']=='CONFORME':continue
    p=r/'numerics/explicit_S_turing'/(rel+'.new')
    if p.exists():print(rel,p.read_text().splitlines()[-1])
if d.get('finished'):print('FINISHED',d['finished'],'SECONDS',d['duration_seconds'])
