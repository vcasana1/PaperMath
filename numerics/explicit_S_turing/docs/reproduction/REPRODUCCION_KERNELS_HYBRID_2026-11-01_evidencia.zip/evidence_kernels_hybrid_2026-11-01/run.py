import ast,datetime,difflib,hashlib,json,os,platform,re,shutil,signal,subprocess,sys,time
from decimal import Decimal,ROUND_CEILING,localcontext
from fractions import Fraction
from pathlib import Path
from zoneinfo import ZoneInfo
import flint,numpy

ROOT=Path('/Users/vcasana/PaperMath-repro-kernels-2026-11-01')
BASE=ROOT/'numerics/explicit_S_turing'
E=ROOT/'evidence_kernels_hybrid_2026-11-01'
OLDROOT=Path('/Users/vcasana/PaperMath-repro')
OLD=OLDROOT/'repro_evidence_2026-11-01'
REPORT=ROOT/'REPRODUCCION_KERNELS_HYBRID_2026-11-01.md'
TAGS=['L5','L20','L60','L150','C400','D6000']
CERTS=[f'family/line_{tag}/cert_kernel.txt' for tag in TAGS]+['hybrid_asymptotic/cert_m10P.txt']
now=lambda:datetime.datetime.now(ZoneInfo('Europe/Madrid')).isoformat()
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,obj):
    t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n');t.replace(p)
def remove_times(text):
    return re.sub(r'\s+time \d+s','',text).strip()
def new_provenance(text):
    return text.replace('certify_hybrid.py sha256 '+old_code_hash,'certify_hybrid.py sha256 '+code_hash)
def mathematical(text):
    return re.sub(r'^python .*\n','',remove_times(new_provenance(text)),flags=re.M)
def stats(text):
    return {'boxes':[int(x) for x in re.findall(r'certified, boxes (\d+)',text)],
            'enclosure':re.findall(r'enclosure of C with directed rounding: (\[[^\n]+\])',text),
            'bound':re.search(r'all certified;\s+C < (\S+)',text).group(1) if 'all certified' in text else None,
            'seconds':int(re.findall(r'time (\d+)s',text)[-1]) if re.findall(r'time (\d+)s',text) else None}
def provenance(text,rel,published=False):
    out=[]
    for name,h in re.findall(r'^(\S+) sha256 ([0-9a-f]{64})$',text,re.M):
        candidates=[(BASE/rel).parent/name,BASE/'hybrid_asymptotic'/name]
        p=next(x for x in candidates if x.exists())
        if published and name=='certify_hybrid.py':p=OLD/'baseline/hybrid_asymptotic/certify_hybrid.py'
        assert sha(p.read_bytes())==h,('provenance mismatch',rel,name,h)
        out.append({'name':name,'sha256':h,'verified_against':str(p)})
    assert len(out)==(4 if rel.startswith('hybrid_asymptotic') else 3)
    return out

assert ROOT.resolve()==ROOT and not E.exists() and not REPORT.exists()
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==''
assert flint.__version__=='0.9.0'
E.mkdir();(E/'events').mkdir();(E/'bin').mkdir()
started=now();start=time.monotonic()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
code=BASE/'hybrid_asymptotic/certify_hybrid.py';old_code=OLD/'baseline/hybrid_asymptotic/certify_hybrid.py'
code_hash=sha(code.read_bytes());old_code_hash=sha(old_code.read_bytes())
assert ast.dump(ast.parse(code.read_text()))==ast.dump(ast.parse(old_code.read_text())),'Executable AST changed; inspect before running'
code_diff=''.join(difflib.unified_diff(old_code.read_text().splitlines(True),code.read_text().splitlines(True),fromfile='prior/certify_hybrid.py',tofile='current/certify_hybrid.py'))
(E/'certifier_comments.diff').write_text(code_diff)
tracked={}
for rel in subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0'):
    if rel:tracked[rel]=sha((ROOT/rel).read_bytes())
save(E/'tracked_sha256_before.json',tracked)
prior_guards={}
for p in [OLDROOT/'REPRODUCCION_2026-11-01.md',OLDROOT/'REPRODUCCION_2026-11-01_evidencia.zip',OLD/'state.json',
          Path('/Users/vcasana/Downloads/REPRODUCCION_2026-11-01.md'),Path('/Users/vcasana/Downloads/REPRODUCCION_2026-11-01_evidencia.zip')]:
    prior_guards[str(p)]=sha(p.read_bytes())
save(E/'prior_delivery_sha256.json',prior_guards)
rows={}
for rel in CERTS:
    published=(BASE/rel).read_bytes();prior=(OLD/'reproduced'/rel).read_bytes()
    assert published==(OLD/'baseline'/rel).read_bytes(),('published reference changed',rel)
    for folder,data in [('published',published),('previous_mac',prior)]:
        p=E/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    rows[rel]={'status':'PENDIENTE','published_sha256':sha(published),'previous_mac_sha256':sha(prior),
               'published':stats(published.decode()),'previous_mac':stats(prior.decode()),
               'published_provenance':provenance(published.decode(),rel,True)}
for rel in ['hybrid_asymptotic/'+x for x in ['certify_hybrid.py','certutil.py','profile_published.py','hyb_m10_P.json']]+['rerun/rerun_kernels_hybrid.sh']+[f'family/line_{tag}/{name}' for tag in TAGS for name in ['sol.json','summary_pp.json','sol_czpp.json','sol_elem.json','sol_elemS.json']]:
    p=E/'sources'/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(BASE/rel,p)
p=E/'prior_source/certify_hybrid.py';p.parent.mkdir();shutil.copy2(old_code,p)
for name in ['run.py','python3']:
    dest=E/('python3_timing_wrapper.py' if name=='python3' else name);shutil.copy2(Path('/private/tmp/papermath-kernels-2026-11-01')/name,dest)
shutil.copy2('/private/tmp/papermath-kernels-2026-11-01/python3',E/'bin/python3');(E/'bin/python3').chmod(0o755)
hw=json.loads(subprocess.check_output(['system_profiler','SPHardwareDataType','-json'],text=True))['SPHardwareDataType']
hw=[{k:v for k,v in x.items() if not any(t in k.lower() for t in ['serial','uuid','provisioning'])} for x in hw]
metadata={'started':started,'commit':commit,'branch':'explicit-S-turing','clone':str(ROOT),'python':sys.version,'executable':sys.executable,
          'python_flint':flint.__version__,'FLINT':getattr(flint,'__FLINT_VERSION__','unknown'),'numpy':numpy.__version__,
          'platform':platform.platform(),'sw_vers':subprocess.check_output(['sw_vers'],text=True),'hardware':hw,
          'launcher':'./rerun/rerun_kernels_hybrid.sh 4','certifier_sha256':code_hash,'old_certifier_sha256':old_code_hash,
          'executable_AST_identical':True,'predeclared_comparison':'Compare every numeric byte, enclosure and box count. Accept only elapsed-time differences, the known certifier SHA change caused solely by comments, and Python version differences against published 3.13.18 (current and previous Mac use 3.14.5).',
          'execution_independence':'All seven jobs run locally from their inputs. No remote outputs used to construct results.',
          'prior_mac_environment':json.loads((OLD/'metadata.json').read_text())}
save(E/'metadata.json',metadata)
(E/'pip_freeze.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
state={'started':started,'phase':'EJECUTANDO','commit':commit,'results':rows,'incidents':[],'constants':{}}

def report():
    save(E/'state.json',state)
    n=sum(x['status']=='CONFORME' for x in rows.values())
    lines=['# Reproducción independiente de los seis núcleos y el híbrido — 2026-11-01','',
           f"**Estado global: {state['phase']}. Resultados conformes: {n}/7.**",'',
           f'Inicio: {started}. Actualización: {now()}.',
           f'Repositorio: https://github.com/vcasana1/PaperMath/tree/{commit}/numerics/explicit_S_turing',
           f'Commit fijado: `{commit}`; rama `explicit-S-turing`; clon nuevo: `{ROOT}`.',
           'Se ejecutó `git pull --ff-only` en el clon limpio antes de fijar el commit y lanzar los cálculos. La reproducción anterior permanece conservada.',
           f'Comando ejecutado: `./rerun/rerun_kernels_hybrid.sh 4`. Cuatro procesos como máximo, exclusivamente en este Mac.',
           f'Python `{platform.python_version()}`; `python-flint {flint.__version__}`; FLINT `{metadata["FLINT"]}`; numpy `{numpy.__version__}`. Entorno nuevo `.venv-repro/`. Precisión verificada en las siete salidas: 256 bits.',
           f'Sistema `{platform.platform()}`. Hardware: `{json.dumps(hw,ensure_ascii=False)}`.',
           'El wrapper python3 mide tiempos y ejecuta el Python del entorno. No modifica el lanzador ni los programas de certificación.',
           'Esta ejecución recalcula siete certificados. Los otros dieciocho certificados C_zeta/elementales pertenecen a la reproducción anterior y aquí no se vuelven a ejecutar.',
           'Los cálculos se generan localmente desde las entradas fijadas; no se usan resultados de la ejecución remota para construirlos.','',
           '## Criterio de comparación fijado antes del cálculo','',
           f'El certificador publicado previamente tenía SHA-256 `{old_code_hash}`. El certificador actual tiene `{code_hash}`. El diff solo cambia comentarios y el AST ejecutable es idéntico (`certifier_comments.diff`).',
           'Se comparan todos los números, cotas, inclusiones, radios y cuentas de cajas. Las únicas diferencias previstas y admitidas son los tiempos, el nuevo hash del certificador por sus comentarios y la línea Python 3.13.18 publicada frente a Python 3.14.5 local.',
           'También se compara con la reproducción anterior de este mismo Mac, que utiliza la misma versión de Python: en esa comparación solo se admiten tiempos y el hash conocido del certificador. Se conservan los diffs completos y todos los hashes originales.',
           'Por ello, la afirmación “idéntico byte a byte salvo time” no se da por supuesta para los certificados publicados antiguos: sus líneas de procedencia contienen el hash anterior y otra versión de Python.',
           'Cualquier diferencia no prevista detiene el grupo de procesos.','',
           '## Resultados individuales','',
           '| Certificado | Veredicto | Cota C < | Inclusión dirigida | Cajas + / − / cola | Publicado s | Mac anterior s | Mac nuevo s | Pared nueva s | Diferencia matemática |',
           '|---|---|---|---|---|---:|---:|---:|---:|---|']
    for rel,row in rows.items():
        new=row.get('new',{});st=new or row['published'];wall=row.get('wall_seconds');wall=f'{wall:.3f}' if wall is not None else 'pendiente'
        lines.append(f"| `{rel}` | {row['status']} | {st['bound']} | `{'; '.join(st['enclosure'])}` | {' / '.join(map(str,st['boxes']))} | {row['published']['seconds']} | {row['previous_mac']['seconds']} | {new.get('seconds','pendiente')} | {wall} | {row.get('math_difference','pendiente')} |")
    lines+=['','## SHA-256 de los archivos de salida','',
            '| Certificado | Publicado original | Nueva salida completa | Contenido numérico normalizado |','|---|---|---|---|']
    for rel,row in rows.items():
        lines.append(f"| `{rel}` | `{row['published_sha256']}` | `{row.get('new_sha256','pendiente')}` | `{row.get('numeric_sha256','pendiente')}` |")
    if state['constants']:
        lines+=['','## Constantes de las seis rectas','',
                'A1 se recalcula del coeficiente exacto c_R1 con Arb y redondeo dirigido; A3_N y A3_S se vuelven a sumar con Decimal a partir de los JSON C_zeta/elementales conservados. Esto no implica haber recalculado esos dieciocho certificados en esta segunda ejecución.','',
                '| Recta | A1 | A3_N | A3_S | Coincide con el resumen fijado |','|---|---|---|---|---|']
        for tag,v in state['constants'].items():lines.append(f"| {tag} | {v['A1']} | {v['A3_N']} | {v['A3_S']} | Sí |")
    lines+=['','## Evidencia e integridad','',
            'Las salidas nuevas quedan como `cert_*.txt.new`, conforme al lanzador. Las copias publicadas se conservan intactas; no se instalan resultados ni se hacen commits ni se genera un manuscrito nuevo.',
            'La evidencia conserva las fuentes exactas, siete entradas, referencias publicadas y del Mac anterior, siete salidas nuevas, registros por invocación, hashes antes/después y diferencias completas.',
            f'Tiempo de la fase registrada transcurrido: {time.monotonic()-start:.3f} s. Los tiempos de pared individuales corresponden a ejecución concurrente y no deben sumarse como duración global.',
            'La reproducción verifica estos cálculos finitos. No sustituye la evaluación de las demostraciones analíticas del manuscrito.']
    if state.get('finished'):lines+=['',f"Fin: {state['finished']}. Duración registrada: {state['duration_seconds']:.3f} s ({state['duration_seconds']/60:.3f} min)."]
    if state.get('integrity'):lines+=['',json.dumps(state['integrity'],ensure_ascii=False)]
    if state['incidents']:lines+=['','## Incidencias','']+state['incidents']
    tmp=REPORT.with_suffix('.md.tmp');tmp.write_text('\n'.join(lines)+'\n');tmp.replace(REPORT)

def check(rel,event):
    p=BASE/(rel+'.new');data=p.read_bytes();text=data.decode();pub=(E/'published'/rel).read_text();prev=(E/'previous_mac'/rel).read_text()
    assert 'all certified' in text and 'python-flint 0.9.0, precision 256 bits' in text,(rel,'invalid completion')
    prov=provenance(text,rel)
    same_math=mathematical(text)==mathematical(pub)
    same_mac=remove_times(text)==remove_times(new_provenance(prev))
    row=rows[rel];row.update(new=stats(text),new_sha256=sha(data),wall_seconds=event['wall_seconds'],
                            cpu_user_seconds=event['cpu_user_seconds'],cpu_system_seconds=event['cpu_system_seconds'],
                            new_provenance=prov,numeric_sha256=sha(mathematical(text).encode()),
                            numeric_published_sha256=sha(mathematical(pub).encode()),
                            previous_mac_equal_after_expected_changes=same_mac,
                            math_difference='ninguna' if same_math else 'DETECTADA')
    out=E/'reproduced'/(rel+'.new');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
    for label,reference in [('published',pub),('previous_mac',prev)]:
        d=E/'diffs'/label/(rel+'.diff');d.parent.mkdir(parents=True,exist_ok=True)
        d.write_text(''.join(difflib.unified_diff(reference.splitlines(True),text.splitlines(True),fromfile=label+'/'+rel,tofile='new/'+rel+'.new')))
    if not same_math or not same_mac:
        row['status']='DISCREPANCIA';raise RuntimeError('Unexpected certificate difference: '+rel)
    assert row['new']['boxes']==row['published']['boxes'] and row['new']['enclosure']==row['published']['enclosure']
    row['status']='CONFORME';print('VERIFIED',rel,round(event['wall_seconds'],3),'s',flush=True)

report()
env=os.environ.copy();env.update(PATH=str(E/'bin')+':'+str(ROOT/'.venv-repro/bin')+':'+env.get('PATH',''),PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',VECLIB_MAXIMUM_THREADS='1')
log=open(E/'launcher.log','w',buffering=1)
proc=subprocess.Popen(['./rerun/rerun_kernels_hybrid.sh','4'],cwd=BASE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
state['process_group']=proc.pid;report();seen=set()
try:
    while True:
        for p in sorted((E/'events').glob('*.json')):
            if p.name in seen:continue
            event=json.loads(p.read_text());seen.add(p.name);args=event['args']
            assert Path(args[0]).name=='certify_hybrid.py',args
            rel='hybrid_asymptotic/cert_m10P.txt' if args[1]=='hyb_m10_P.json' else 'family/'+str(Path(args[1]).parent)+'/cert_kernel.txt'
            if event['returncode'] and args[1]!='hyb_m10_P.json' and args[2]=='100':
                state.setdefault('retries',[]).append(event);continue
            if event['returncode']:raise RuntimeError('Certificate subprocess failed: '+str(event))
            check(rel,event);report()
        if proc.poll() is not None:
            if {p.name for p in (E/'events').glob('*.json')}-seen:continue
            break
        time.sleep(2)
    assert proc.returncode==0 and all(x['status']=='CONFORME' for x in rows.values()),'Incomplete run'
    sys.path.insert(0,str(BASE/'hybrid_asymptotic'))
    from certutil import A,up_str
    for tag in TAGS:
        folder=BASE/f'family/line_{tag}';sol=json.loads((folder/'sol.json').read_text());old=json.loads((folder/'summary_pp.json').read_text())
        c1=A(Fraction(sol['c'][0]))/(2*flint.arb.pi())
        with localcontext() as dc:
            dc.prec=100
            a1=str(Decimal(up_str(c1,80)).quantize(Decimal('.00001'),rounding=ROUND_CEILING))
            cz=Decimal(json.loads((folder/'sol_czpp.json').read_text())['Czeta_upper'])
            fn=Decimal(json.loads((folder/'sol_elem.json').read_text())['Fsup_upper']);fs=Decimal(json.loads((folder/'sol_elemS.json').read_text())['Fsup_upper'])
            an=str((cz+fn).quantize(Decimal('.001'),rounding=ROUND_CEILING));ass=str((cz+fs).quantize(Decimal('.001'),rounding=ROUND_CEILING))
        assert A(Fraction(a1))>=c1
        constants={'A1':a1,'A3_N':an,'A3_S':ass};assert constants=={k:old[k] for k in constants}
        state['constants'][tag]=constants
    changed=[rel for rel,h in tracked.items() if sha((ROOT/rel).read_bytes())!=h]
    assert not changed,('Tracked files changed',changed)
    assert all(sha(Path(p).read_bytes())==h for p,h in prior_guards.items()),'Prior delivery changed'
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==commit
    assert subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True)==''
    state['integrity']={'tracked_files_checked':len(tracked),'tracked_files_changed':0,'manuscripts_unchanged':True,'published_certificates_unchanged':True,
                        'previous_delivery_unchanged':True,'commits_created':0,'new_outputs':7,'verified_provenance_hash_references':sum(len(x['new_provenance']) for x in rows.values())}
    state['phase']='CONFORME — 7/7 REPRODUCIDOS EN EL MAC';state['finished']=now();state['duration_seconds']=time.monotonic()-start;report()
    print(state['phase'],str(REPORT),flush=True)
except BaseException as exc:
    if proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    state['phase']='DETENIDA — REQUIERE EXAMEN';state['incidents'].append(repr(exc));state['finished']=now();state['duration_seconds']=time.monotonic()-start;report()
    print('STOPPED',repr(exc),flush=True);raise
finally:log.close()
