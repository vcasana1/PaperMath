import datetime,hashlib,json,os,re,shutil,subprocess
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from zoneinfo import ZoneInfo

ROOT=Path('/Users/vcasana/PaperMath-repro-kernels-2026-11-01')
BASE=ROOT/'numerics/explicit_S_turing';E=ROOT/'evidence_kernels_hybrid_2026-11-01'
REPORT=ROOT/'REPRODUCCION_KERNELS_HYBRID_2026-11-01.md'
sha=lambda b:hashlib.sha256(b).hexdigest()
state=json.loads((E/'state.json').read_text());meta=json.loads((E/'metadata.json').read_text())
assert state['phase']=='CONFORME — 7/7 REPRODUCIDOS EN EL MAC' and not state['incidents']
assert len(state['results'])==7 and all(v['status']=='CONFORME' for v in state['results'].values())
try:os.killpg(state['process_group'],0)
except ProcessLookupError:pass
else:raise RuntimeError('Calculation process group still exists')
check={'process_group':state['process_group'],'remaining_processes':False,'checked_at':datetime.datetime.now(ZoneInfo('Europe/Madrid')).isoformat()}
(E/'process_absence.json').write_text(json.dumps(check,indent=2)+'\n')
before=json.loads((E/'tracked_sha256_before.json').read_text())
assert all(sha((ROOT/p).read_bytes())==h for p,h in before.items())
assert all(sha(Path(p).read_bytes())==h for p,h in json.loads((E/'prior_delivery_sha256.json').read_text()).items())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==state['commit']
assert subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True)==''
def normalized(s):
    s=s.replace('certify_hybrid.py sha256 '+meta['old_certifier_sha256'],'certify_hybrid.py sha256 '+meta['certifier_sha256'])
    s=re.sub(r'\s+time \d+s','',s).strip()
    return re.sub(r'^python .*\n','',s,flags=re.M)
for rel,row in state['results'].items():
    new=(BASE/(rel+'.new')).read_bytes();pub=(E/'published'/rel).read_bytes()
    assert sha(new)==row['new_sha256'] and sha(pub)==row['published_sha256']
    assert normalized(new.decode())==normalized(pub.decode())
    assert sha(normalized(new.decode()).encode())==row['numeric_sha256']==row['numeric_published_sha256']
    assert (E/'reproduced'/(rel+'.new')).read_bytes()==new
for name in ['run.py','python3','status.py','compare_remote.py','finish.py']:
    src=Path('/private/tmp/papermath-kernels-2026-11-01')/name
    shutil.copy2(src,E/('python3_timing_wrapper.py' if name=='python3' else name))
text=REPORT.read_text()
text=text.replace('Reproducción independiente de los seis núcleos y el híbrido','Reejecución en el Mac de los seis núcleos y el híbrido')
text+='\n## Cierre y entrega\n\n'
text+=f'**Veredicto global: CONFORME, 7/7.** Las cotas, inclusiones y cuentas de cajas reproducen las referencias publicadas y la ejecución anterior del Mac. Las 22 referencias SHA-256 impresas en las nuevas salidas corresponden exactamente a las entradas y programas del commit fijado.\n\n'
text+=f'Inicio: {state["started"]}. Fin del cálculo y comprobaciones: {state["finished"]}. Duración de la fase registrada: **{state["duration_seconds"]:.3f} s ({state["duration_seconds"]/60:.3f} min)**; excluye la clonación e instalación del entorno.\n\n'
text+='Las diferencias de archivo están clasificadas en los diffs: tiempos; hash del certificador cambiado exclusivamente por comentarios; y versión de Python respecto a la referencia publicada antigua. Frente al Mac anterior, la línea de Python coincide. Ninguna diferencia matemática.\n\n'
remote=E/'remote_comparison.json'
if remote.exists():
    remote_data=json.loads(remote.read_text())
    text+='### Comparación con la rama remota al terminar\n\n'
    text+=f'Esta consulta se hizo después de cerrar y conservar las salidas locales. Ref remoto: `{remote_data.get("remote_commit","no disponible")}`.\n\n'
    assert not remote_data.get('unexpected_numeric_difference'),'Unresolved remote difference'
    for row in remote_data.get('certificates',[]):
        text+=f'- `{row["certificate"]}`: {row["status"]}.\n'
    if remote_data.get('note'):text+='\n'+remote_data['note']+'\n'
    text+='\n'
text+=f'Se verificaron {len(before)} archivos seguidos por Git: todos permanecen byte a byte intactos. Los siete resultados nuevos quedan como `.new`; los certificados publicados y los manuscritos no se han modificado. La reproducción anterior y sus entregables conservan sus hashes. No se han creado commits.\n\n'
text+=f'El grupo de procesos {state["process_group"]} ya no existe, comprobado a las {check["checked_at"]}.\n\n'
text+='Entrega: este informe y `REPRODUCCION_KERNELS_HYBRID_2026-11-01_evidencia.zip`. El ZIP contiene fuentes, entradas, las siete salidas nuevas, dos referencias por certificado, diffs, versiones, tiempos y manifiesto SHA-256.\n'
text+='\nPara el traspaso, los siete resultados nuevos se incluyen también directamente en las rutas `hybrid_asymptotic/cert_m10P.txt.new` y `family/line_*/cert_kernel.txt.new` de la raíz del ZIP. Sus hashes están en `SHA256_CERTIFICADOS_MAC.txt`. Son salidas originales del programa, sin cambiar su línea de Python ni sus tiempos. No se ha ejecutado finalize.py ni se han instalado los certificados.\n'
REPORT.write_text(text);shutil.copy2(REPORT,E/REPORT.name)
(E/'certificate_delivery_sha256.txt').write_text(''.join(row['new_sha256']+'  '+rel+'.new\n' for rel,row in state['results'].items()))
(E/'git_status_final.txt').write_text(subprocess.check_output(['git','status','--short','--branch'],cwd=ROOT,text=True))
manifest={str(p.relative_to(E)):sha(p.read_bytes()) for p in sorted(E.rglob('*')) if p.is_file() and p.name!='evidence_sha256.json'}
(E/'evidence_sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=ROOT/'REPRODUCCION_KERNELS_HYBRID_2026-11-01_evidencia.zip'
assert not archive.exists()
with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
    z.write(REPORT,REPORT.name)
    z.write(E/'certificate_delivery_sha256.txt','SHA256_CERTIFICADOS_MAC.txt')
    for rel in state['results']:z.write(E/'reproduced'/(rel+'.new'),rel+'.new')
    for p in sorted(E.rglob('*')):
        if p.is_file():z.write(p,'evidence_kernels_hybrid_2026-11-01/'+str(p.relative_to(E)))
with ZipFile(archive) as z:assert z.testzip() is None
deliveries=[]
for src in [REPORT,archive]:
    target=Path('/Users/vcasana/Downloads')/src.name
    if target.exists() and sha(target.read_bytes())!=sha(src.read_bytes()):
        target=target.with_name(target.stem+'_'+datetime.datetime.now(ZoneInfo('Europe/Madrid')).strftime('%H%M%S')+target.suffix)
        assert not target.exists()
    if not target.exists():shutil.copy2(src,target)
    assert sha(src.read_bytes())==sha(target.read_bytes())
    deliveries.append({'source':str(src),'copy':str(target),'sha256':sha(src.read_bytes()),'bytes':src.stat().st_size})
(ROOT/'REPRODUCCION_KERNELS_HYBRID_2026-11-01_entrega.json').write_text(json.dumps(deliveries,indent=2)+'\n')
print(json.dumps({'checks':'PASS','duration_seconds':state['duration_seconds'],'deliveries':deliveries},indent=2))
