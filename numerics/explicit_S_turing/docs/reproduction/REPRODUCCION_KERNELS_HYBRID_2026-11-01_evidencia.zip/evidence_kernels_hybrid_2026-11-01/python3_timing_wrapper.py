#!/Users/vcasana/PaperMath-repro-kernels-2026-11-01/.venv-repro/bin/python3
import datetime,json,os,resource,subprocess,sys,time,uuid
from pathlib import Path
r=Path('/Users/vcasana/PaperMath-repro-kernels-2026-11-01')
e=r/'evidence_kernels_hybrid_2026-11-01'
args=sys.argv[1:];start=time.monotonic()
rec={'args':args,'cwd':os.getcwd(),'started':datetime.datetime.now(datetime.timezone.utc).isoformat()}
ret=subprocess.run([str(r/'.venv-repro/bin/python3'),*args])
usage=resource.getrusage(resource.RUSAGE_CHILDREN)
rec.update(returncode=ret.returncode,wall_seconds=time.monotonic()-start,
           cpu_user_seconds=usage.ru_utime,cpu_system_seconds=usage.ru_stime,
           ended=datetime.datetime.now(datetime.timezone.utc).isoformat())
if ret.returncode and args and Path(args[0]).name=='certify_hybrid.py':
    out=Path('cert_m10P.txt.new') if args[1]=='hyb_m10_P.json' else Path(args[1]).parent/'cert_kernel.txt.new'
    if out.exists():rec['failed_output']=out.read_text()
p=e/'events'/(str(uuid.uuid4())+'.json');temp=p.with_suffix('.tmp')
temp.write_text(json.dumps(rec,indent=2));temp.replace(p)
sys.exit(ret.returncode)
