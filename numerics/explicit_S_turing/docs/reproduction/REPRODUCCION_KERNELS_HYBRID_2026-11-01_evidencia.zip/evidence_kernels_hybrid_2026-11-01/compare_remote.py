import difflib,hashlib,json,re,subprocess,sys
from pathlib import Path
r=Path('/Users/vcasana/PaperMath-repro-kernels-2026-11-01');e=r/'evidence_kernels_hybrid_2026-11-01'
d=json.loads((e/'state.json').read_text())
assert d['phase']=='CONFORME — 7/7 REPRODUCIDOS EN EL MAC'
for rel,row in d['results'].items():assert hashlib.sha256((e/'reproduced'/(rel+'.new')).read_bytes()).hexdigest()==row['new_sha256']
fetch=subprocess.run(['git','fetch','origin','explicit-S-turing'],cwd=r,capture_output=True,text=True)
(e/'remote_fetch.log').write_text(fetch.stdout+fetch.stderr)
result={'performed_only_after_local_outputs_were_frozen':True,'certificates':[],'fetch_returncode':fetch.returncode}
if fetch.returncode:
    result['note']='No se pudo actualizar la referencia remota. La comprobación local usa las referencias fijadas antes del cálculo.'
else:
    commit=subprocess.check_output(['git','rev-parse','FETCH_HEAD'],cwd=r,text=True).strip();result['remote_commit']=commit
    def norm(s):return re.sub(r'^python .*\n','',re.sub(r'\s+time \d+s','',s).strip(),flags=re.M)
    def prov(s):return re.findall(r'^(\S+) sha256 ([0-9a-f]{64})$',s,re.M)
    mismatch=False
    for rel,row in d['results'].items():
        path='numerics/explicit_S_turing/'+rel
        local=(e/'reproduced'/(rel+'.new')).read_text()
        remote=None;selected_path=path
        for candidate in [path,path+'.new']:
            probe=subprocess.run(['git','show',commit+':'+candidate],cwd=r,capture_output=True)
            if probe.returncode:continue
            if remote is None:remote=probe;selected_path=candidate
            candidate_text=probe.stdout.decode()
            if 'all certified' in candidate_text and prov(candidate_text)==prov(local):
                remote=probe;selected_path=candidate;break
        item={'certificate':rel}
        if remote is None:
            item['status']='Referencia no disponible en el commit remoto'
        else:
            data=remote.stdout;text=data.decode();item['remote_path']=selected_path
            suffix='.new' if selected_path.endswith('.new') else ''
            p=e/'remote_published'/(rel+suffix);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
            item['remote_sha256']=hashlib.sha256(data).hexdigest()
            item['provenance_equal_to_local']=prov(text)==prov(local)
            if 'all certified' not in text:
                item['status']='Referencia remota todavía incompleta; no comparable como certificado final'
            elif not item['provenance_equal_to_local']:
                item['status']='No comparable como certificado actualizado: los hashes de procedencia son diferentes'
            elif 'python-flint 0.9.0, precision 256 bits' not in text:
                item['status']='No comparable: versión de FLINT o precisión distinta'
            else:
                same=norm(text)==norm(local);item['numeric_content_equal']=same
                item['status']='CONFORME con la referencia remota actualizada; solo difieren tiempos y/o la línea de versión de Python' if same else 'DIFERENCIA NO PREVISTA con la referencia remota de igual procedencia'
                p=e/'remote_diffs'/(rel+'.diff');p.parent.mkdir(parents=True,exist_ok=True)
                p.write_text(''.join(difflib.unified_diff(text.splitlines(True),local.splitlines(True),fromfile='remote/'+rel,tofile='local/'+rel+'.new')))
                mismatch|=not same
        result['certificates'].append(item)
    result['unexpected_numeric_difference']=mismatch
    if mismatch:
        result['note']='DETENIDA LA ENTREGA CONFORME: existe una diferencia con una referencia remota que declara las mismas entradas y programas. Examinar remote_diffs.'
        d['phase']='DETENIDA — DIFERENCIA REMOTA CON IGUAL PROCEDENCIA';d['incidents'].append(result['note'])
        (e/'state.json').write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n')
        report=r/'REPRODUCCION_KERNELS_HYBRID_2026-11-01.md'
        updated=re.sub(r'\*\*Estado global: [^\n]+\*\*','**Estado global: '+d['phase']+'.**',report.read_text())
        report.write_text(updated+'\n## ALERTA de comparación remota\n\n'+result['note']+'\n')
(e/'remote_comparison.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(result,indent=2,ensure_ascii=False))
if result.get('unexpected_numeric_difference'):sys.exit(2)
