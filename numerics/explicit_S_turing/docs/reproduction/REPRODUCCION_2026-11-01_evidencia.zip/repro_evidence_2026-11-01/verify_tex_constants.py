from pathlib import Path
from fractions import Fraction
from decimal import Decimal, ROUND_CEILING, localcontext
import hashlib, json, re, sys
root=Path('/Users/vcasana/PaperMath-repro')
base=root/'numerics/explicit_S_turing'
e=root/'repro_evidence_2026-11-01'
sys.path.insert(0,str(base/'hybrid_asymptotic'))
from certutil import A, up_str
from flint import arb
tex=Path('/Users/vcasana/Downloads/casanya_turing_jensen_v9_l_1.tex')
text=tex.read_text(); rows=[]
for tag,macro in [('L5','Five'),('L20','Twenty'),('L60','Sixty'),('L150','OneFifty'),('C400','FourH'),('D6000','B')]:
    folder=base/f'family/line_{tag}'
    sol=json.loads((folder/'sol.json').read_text())
    old=json.loads((e/'baseline'/f'family/line_{tag}/summary_pp.json').read_text())
    cz=json.loads((folder/'sol_czpp.json').read_text())['Czeta_upper']
    n=json.loads((folder/'sol_elem.json').read_text())['Fsup_upper']
    s=json.loads((folder/'sol_elemS.json').read_text())['Fsup_upper']
    c1=A(Fraction(sol['c'][0]))/(2*arb.pi())
    with localcontext() as dc:
        dc.prec=100
        values={'A1':str(Decimal(up_str(c1,80)).quantize(Decimal('.00001'),rounding=ROUND_CEILING)),
                'A3_N':str((Decimal(cz)+Decimal(n)).quantize(Decimal('.001'),rounding=ROUND_CEILING)),
                'A3_S':str((Decimal(cz)+Decimal(s)).quantize(Decimal('.001'),rounding=ROUND_CEILING))}
    assert A(Fraction(values['A1']))>=c1
    macros={}
    for key,suffix in [('A1','Aone'),('A3_N','AthreeN'),('A3_S','AthreeS')]:
        match=re.search(r'\\newcommand\{\\Line'+macro+suffix+r'\}\{([^}]+)\}',text)
        assert match and match.group(1)==values[key]==old[key],(tag,key,match,values,old)
        macros['Line'+macro+suffix]=match.group(1)
    rows.append({'line':tag,'C1_ball':c1.str(70),'Czeta_upper':cz,'Fsup_N':n,'Fsup_S':s,
                 'computed':values,'tex_macros':macros,'verdict':'18 constantes conformes' if tag=='D6000' else 'conforme'})
out={'tex_path':str(tex),'tex_sha256':hashlib.sha256(tex.read_bytes()).hexdigest(),
     'rounding':'A1: c_R1/(2pi) redondeado hacia arriba a 5 decimales; A3: suma Decimal exacta redondeada hacia arriba a 3 decimales',
     'rows':rows,'all_18_equal_to_published_summary_and_supplied_tex':True}
(e/'tex_constants_verification.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(out,indent=2,ensure_ascii=False))
