#!/Users/vcasana/PaperMath-repro/.venv-repro/bin/python3
import datetime, json, os, resource, subprocess, sys, time, uuid
from pathlib import Path

args = sys.argv[1:]
record = {'args': args, 'cwd': os.getcwd(), 'started': datetime.datetime.now(datetime.timezone.utc).isoformat()}
start = time.monotonic()
result = subprocess.run(['/Users/vcasana/PaperMath-repro/.venv-repro/bin/python3', *args])
record.update(returncode=result.returncode, seconds=time.monotonic()-start,
              ended=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              child_usage=list(resource.getrusage(resource.RUSAGE_CHILDREN)))
folder = Path('/Users/vcasana/PaperMath-repro/repro_evidence_2026-11-01/events')
target = folder / (str(uuid.uuid4())+'.json')
temporary = target.with_suffix('.tmp')
temporary.write_text(json.dumps(record, indent=2))
temporary.replace(target)
sys.exit(result.returncode)
