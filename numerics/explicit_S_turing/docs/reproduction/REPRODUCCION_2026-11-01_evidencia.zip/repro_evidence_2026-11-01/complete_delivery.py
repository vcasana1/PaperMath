from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
from datetime import datetime
from zoneinfo import ZoneInfo
import hashlib, json, os, re, shutil, subprocess

root=Path('/Users/vcasana/PaperMath-repro')
e=root/'repro_evidence_2026-11-01';base=root/'numerics/explicit_S_turing'
report=root/'REPRODUCCION_2026-11-01.md'
state=json.loads((e/'state.json').read_text())
assert state['phase']=='REPRODUCCIÓN CONFORME — 25/25; SEIS RECTAS CONFORMES',state['phase']
assert len(state['results'])==25 and all(x['status']=='REPRODUCIDO' for x in state['results'].values())
assert not state['discrepancies'] and state['finalize']['returncode']==0
assert len(state['line_constants'])==6
try:
    os.killpg(state['process_group'],0)
except ProcessLookupError:
    process_check={'process_group':state['process_group'],'remaining_processes':False,
                   'checked_at':datetime.now(ZoneInfo('Europe/Madrid')).isoformat()}
else:
    raise RuntimeError('El grupo de cálculo aún existe; no cerrar la entrega')
(e/'process_absence.json').write_text(json.dumps(process_check,indent=2)+'\n')
assert json.loads((e/'tex_constants_verification.json').read_text())['all_18_equal_to_published_summary_and_supplied_tex']
sha=lambda b:hashlib.sha256(b).hexdigest()
tex=Path('/Users/vcasana/Downloads/casanya_turing_jensen_v9_l_1.tex').read_text()
section=tex[tex.index('\\section{Outputs of the certification programs}'):]
blocks=re.findall(r'\\begin\{lstlisting\}\n(.*?)\\end\{lstlisting\}',section,re.S)
ordered=['hybrid_asymptotic/cert_m10P.txt']+[f'family/line_{tag}/{fn}' for tag in ['L5','L20','L60','L150','C400','D6000'] for fn in ['cert_kernel.txt','cert_czeta_pp.txt','cert_elem.txt','cert_elem_S.txt']]
listings=[]
for i,rel in enumerate(ordered):
    assert blocks[i]==(e/'baseline'/rel).read_text(),rel
    listings.append({'certificate':rel,'tex_listing_sha256':sha(blocks[i].encode()),'byte_identical_to_published_certificate':True})
(e/'tex_certificate_listings_verification.json').write_text(json.dumps(listings,indent=2)+'\n')
def canonical(text):
    text=re.sub(r'^python .*\n','',text,flags=re.M)
    text=re.sub(r'\s+time \d+s','',text)
    text=re.sub(r'\s+\d+s(?=\n|$)','',text)
    return '\n'.join(line.rstrip() for line in text.strip().splitlines())
verification=[]
for rel,row in state['results'].items():
    old=(e/'baseline'/rel).read_bytes();new=(base/rel).read_bytes()
    assert sha(old)==row['published_sha256']
    assert sha(new)==row['reproduced_sha256']
    oldnorm=sha(canonical(old.decode()).encode());newnorm=sha(canonical(new.decode()).encode())
    assert oldnorm==newnorm
    verification.append({'certificate':rel,'published_sha256':sha(old),'reproduced_sha256':sha(new),
                         'normalized_published_sha256':oldnorm,'normalized_reproduced_sha256':newnorm,
                         'only_python_version_and_timing_differ':True})
(e/'independent_final_hash_check.json').write_text(json.dumps(verification,indent=2)+'\n')
tracked=json.loads((e/'baseline_sha256.json').read_text())
allowed=set(state['results'])|{'rerun/finalize.py'}
for rel,digest in tracked.items():
    assert sha((e/'baseline'/rel).read_bytes())==digest
    if rel not in allowed:assert sha((base/rel).read_bytes())==digest,rel
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==state['commit']
for name in ['reproduce.py','python3','verify_tex_constants.py','complete_delivery.py']:
    src=Path('/private/tmp/papermath-order6')/name
    target=e/('audit_python3.py' if name=='python3' else name)
    if src.exists():shutil.copy2(src,target)
started=datetime.fromisoformat(state['started']);finished=datetime.fromisoformat(state['finished'])
duration=(finished-started).total_seconds()
text=report.read_text()
text+='\n## Cierre de la reproducción\n\n'
text+=f'Inicio: {state["started"]}. Fin: {state["finished"]}. Duración total: **{duration:.3f} s ({duration/60:.3f} min)**. Los tiempos por certificado son tiempos de pared bajo concurrencia y no deben sumarse como duración total.\n\n'
text+='**Veredicto global: CONFORME.** Los 25 certificados reproducen todo el contenido numérico publicado; las 76 referencias SHA-256 a datos y programas coinciden. Los 25 hashes de contenido normalizado coinciden; los hashes de los archivos completos difieren por la versión de Python (3.13.18 publicada, 3.14.5 en este Mac) y los tiempos. Los JSON auxiliares y los seis resúmenes coinciden con los publicados.\n\n'
text+='Las 18 constantes se han vuelto a calcular con intervalos y aritmética Decimal exacta y se han contrastado además con las macros del TEX adjunto; evidencia en `tex_constants_verification.json`. Para A1 se certificó también A1 ≥ c_R1/(2π).\n\n'
text+='Los 25 bloques de salida de certificados del apéndice del TEX adjunto son byte a byte idénticos a los certificados originales usados como referencia; evidencia en `tex_certificate_listings_verification.json`.\n\n'
text+='### Inclusiones dirigidas de C\n\nLas inclusiones reproducidas coinciden literalmente con las publicadas.\n\n| Certificado | Inclusión publicada y reproducida |\n|---|---|\n'
for rel,row in state['results'].items():
    for enclosure in row['reproduced']['enclosure']:
        assert enclosure in row['published']['enclosure']
        text+=f'| `{rel}` | `{enclosure}` |\n'
text+='\n### Cotas decimales usadas en las seis rectas\n\nLos valores siguientes provienen de los JSON regenerados y coinciden exactamente con los publicados. Las sumas se redondean hacia arriba a tres decimales para obtener A3_N y A3_S.\n\n| Recta | C_zeta superior | Fsup_N superior | Fsup_S superior |\n|---|---|---|---|\n'
for row in json.loads((e/'tex_constants_verification.json').read_text())['rows']:
    text+=f'| {row["line"]} | {row["Czeta_upper"]} | {row["Fsup_N"]} | {row["Fsup_S"]} |\n'
text+='\n'
text+='`python3 rerun/finalize.py` terminó con código 0 y `finalize ok`, exclusivamente en este clon y con una única adaptación de ruta documentada en `finalize_path.diff`. Después se instaló la salida híbrida según las instrucciones del lanzador. La copia publicada anterior permanece íntegra en `baseline/`; no se han modificado el manuscrito ni los archivos adjuntos, ni creado commits ni v10.\n\n'
text+=f'El proceso principal terminó. Se comprobó la ausencia del grupo de cálculo PGID {state["process_group"]} a las {process_check["checked_at"]}; evidencia en `process_absence.json`.\n'
text+='\nArchivos de entrega: este informe y `REPRODUCCION_2026-11-01_evidencia.zip`, con fuentes conservadas, salidas, diferencias, tiempos, verificaciones y manifiestos SHA-256.\n'
report.write_text(text)
shutil.copy2(report,e/report.name)
manifest={str(p.relative_to(e)):sha(p.read_bytes()) for p in sorted(e.rglob('*')) if p.is_file() and p.name!='evidence_sha256.json'}
(e/'evidence_sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root/'REPRODUCCION_2026-11-01_evidencia.zip'
assert not archive.exists(),'No sobrescribir ZIP previo'
with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for p in sorted(e.rglob('*')):
        if p.is_file():z.write(p,'repro_evidence_2026-11-01/'+str(p.relative_to(e)))
with ZipFile(archive) as z:assert z.testzip() is None
deliveries=[]
for src in [report,archive]:
    target=Path('/Users/vcasana/Downloads')/src.name
    if target.exists() and sha(target.read_bytes())!=sha(src.read_bytes()):
        target=target.with_name(target.stem+'_'+datetime.now(ZoneInfo('Europe/Madrid')).strftime('%H%M%S')+target.suffix)
        assert not target.exists()
    if not target.exists():shutil.copy2(src,target)
    assert sha(target.read_bytes())==sha(src.read_bytes())
    deliveries.append({'source':str(src),'copy':str(target),'sha256':sha(src.read_bytes()),'bytes':src.stat().st_size})
(root/'REPRODUCCION_2026-11-01_entrega.json').write_text(json.dumps(deliveries,indent=2)+'\n')
print(json.dumps({'duration_seconds':duration,'deliveries':deliveries,'all_checks':'PASS'},indent=2))
