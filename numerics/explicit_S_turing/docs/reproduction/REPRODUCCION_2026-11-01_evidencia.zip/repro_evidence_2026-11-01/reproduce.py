#!/Users/vcasana/PaperMath-repro/.venv-repro/bin/python3
import datetime, difflib, hashlib, json, os, platform, re, shutil, signal, subprocess, sys, time
from decimal import Decimal, ROUND_CEILING, localcontext
from fractions import Fraction
from pathlib import Path
from zipfile import ZipFile
from zoneinfo import ZoneInfo
import flint, numpy

ROOT = Path('/Users/vcasana/PaperMath-repro')
BASE = ROOT/'numerics/explicit_S_turing'
E = ROOT/'repro_evidence_2026-11-01'
REPORT = ROOT/'REPRODUCCION_2026-11-01.md'
TAGS = ['L5','L20','L60','L150','C400','D6000']
CERTS = [f'family/line_{tag}/{name}' for tag in TAGS for name in
         ['cert_kernel.txt','cert_czeta_pp.txt','cert_elem.txt','cert_elem_S.txt']]+['hybrid_asymptotic/cert_m10P.txt']
MARKERS = {'cert_kernel.txt':'all certified','cert_czeta_pp.txt':'C_zeta <',
           'cert_elem.txt':'SUP over','cert_elem_S.txt':'SUP over','cert_m10P.txt':'all certified'}
def now(): return datetime.datetime.now(ZoneInfo('Europe/Madrid')).isoformat()
def sha(data): return hashlib.sha256(data).hexdigest()
def save(path, data):
    tmp=path.with_suffix(path.suffix+'.tmp'); tmp.write_text(json.dumps(data,indent=2,ensure_ascii=False)); tmp.replace(path)
def canonical(text):
    text=re.sub(r'^python .*\n','',text,flags=re.M)
    text=re.sub(r'\s+time \d+s','',text)
    text=re.sub(r'\s+\d+s(?=\n|$)','',text)
    return '\n'.join(line.rstrip() for line in text.strip().splitlines())
def hashes(text, cert):
    result=[]
    for name,digest in re.findall(r'^(\S+) sha256 ([0-9a-f]{64})$',text,re.M):
        options=[(BASE/cert).parent/name,BASE/'hybrid_asymptotic'/name,BASE/'family'/name]
        p=next(p for p in options if p.exists())
        actual=sha(p.read_bytes())
        if actual!=digest: raise RuntimeError(f'SHA-256 de procedencia distinto: {cert}, {name}')
        result.append({'file':str(p.relative_to(BASE)), 'sha256':digest})
    expected=4 if cert.endswith('cert_m10P.txt') else 3
    if len(result)!=expected: raise RuntimeError(f'Procedencia incompleta: {cert}')
    return result
def stats(text):
    return {'boxes':re.findall(r'certified, boxes (\d+)',text),
            'intervals':re.findall(r'intervals (\d+)',text),
            'seconds':int(re.findall(r'time (\d+)s',text)[-1]) if re.findall(r'time (\d+)s',text) else None,
            'enclosure':re.findall(r'enclosure of C with directed rounding: (\[[^\n]+\])',text),
            'bound':re.findall(r'(?:all certified;\s+C < |C_zeta < |SUP over T>=1 of max\(F_u,F_l\) <= )(\S+)',text)}

assert ROOT.resolve()==ROOT and not ROOT.is_symlink()
assert not E.exists() and not REPORT.exists(), 'No sobrescribir evidencia previa'
assert subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)==''
E.mkdir(); (E/'events').mkdir(); (E/'baseline').mkdir()
started=now(); run_start=time.monotonic()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
baseline={}
for p in BASE.rglob('*'):
    if p.is_file():
        relative=str(p.relative_to(BASE)); data=p.read_bytes(); baseline[relative]=sha(data)
        q=E/'baseline'/relative; q.parent.mkdir(parents=True,exist_ok=True); q.write_bytes(data)
save(E/'baseline_sha256.json',baseline)
machine=json.loads(subprocess.check_output(['system_profiler','SPHardwareDataType','-json'],text=True))
hardware=[{k:v for k,v in d.items() if not any(s in k.lower() for s in ['serial','uuid','provisioning'])} for d in machine['SPHardwareDataType']]
metadata={'started':started,'commit':commit,'branch':'explicit-S-turing','python':sys.version,'executable':sys.executable,
          'platform':platform.platform(),'machine':platform.machine(),'hardware':hardware,'python_flint':flint.__version__,
          'numpy':numpy.__version__,'flint_version':str(getattr(flint,'__FLINT_VERSION__','unavailable')),
          'sw_vers':subprocess.check_output(['sw_vers'],text=True),'commands':['./run_certificates.sh 8','python3 rerun/finalize.py']}
save(E/'metadata.json',metadata)
(E/'pip_freeze.txt').write_text(subprocess.check_output([sys.executable,'-m','pip','freeze'],text=True))
supplied={}; zip_checks=[]
zpath=Path('/Users/vcasana/Downloads/casanya_turing_jensen_v9_zenodo_1.zip')
tpath=Path('/Users/vcasana/Downloads/casanya_turing_jensen_v9_l_1.tex')
for p in [zpath,tpath]: supplied[str(p)]={'sha256':sha(p.read_bytes()),'size':p.stat().st_size}
with ZipFile(zpath) as z:
    assert z.testzip() is None
    for rel in CERTS:
        p=Path(rel); name=(p.parent.name+'_'+p.name) if rel.startswith('family/') else p.name
        assert z.read(name)==(BASE/rel).read_bytes(), f'ZIP differs: {rel}'
        zip_checks.append({'member':name,'repo':rel,'sha256':baseline[rel]})
    for tag in TAGS:
        for fn in ['sol.json','sol_czpp.json','sol_elem.json','sol_elemS.json','summary_pp.json']:
            rel=f'family/line_{tag}/{fn}'; name=f'line_{tag}_{fn}'
            assert z.read(name)==(BASE/rel).read_bytes(),rel
            zip_checks.append({'member':name,'repo':rel,'sha256':baseline[rel]})
    for rel in ['hybrid_asymptotic/'+x for x in ['certutil.py','certify_hybrid.py','profile_published.py','hyb_m10_P.json']]+['family/'+x for x in ['cz_gen_pp.py','elem_gen.py','certify_line_pp.py']]+['docs/zenodo_note/casanya_turing_jensen_v9_l.tex']:
        assert z.read(Path(rel).name)==(BASE/rel).read_bytes(),rel
        zip_checks.append({'member':Path(rel).name,'repo':rel,'sha256':baseline[rel]})
assert tpath.read_bytes()==(BASE/'docs/zenodo_note/casanya_turing_jensen_v9_l.tex').read_bytes()
assert zpath.read_bytes()==(BASE/'docs/zenodo_note/casanya_turing_jensen_v9_zenodo.zip').read_bytes()
save(E/'supplied_sources.json',{'files':supplied,'zip_crc':'OK','comparisons':zip_checks})
rows={rel:{'status':'PENDIENTE','published_sha256':baseline[rel],'published':stats((BASE/rel).read_text()),
           'provenance':hashes((BASE/rel).read_text(),rel)} for rel in CERTS}
state={'started':started,'phase':'EJECUTANDO','commit':commit,'results':rows,'line_constants':{},'discrepancies':[]}

def report():
    save(E/'state.json',state)
    complete=sum(v['status']=='REPRODUCIDO' for v in rows.values())
    lines=['# Reproducción independiente de casanya_turing_jensen_v9 — 2026-11-01','',
           f"Estado global: **{state['phase']}**. Certificados reproducidos: **{complete}/25**.",
           f"Inicio: {started}. Última actualización: {now()}.",'',
           f'Repositorio: https://github.com/vcasana1/PaperMath/tree/{commit}/numerics/explicit_S_turing',
           f'Rama: `explicit-S-turing`. Commit exacto: `{commit}`.',
           f'Clon independiente: `{ROOT}`. El clon no existía antes de esta ejecución.',
           f'Python: `{platform.python_version()}`; `python-flint=={flint.__version__}`; `numpy=={numpy.__version__}`.',
           f'Sistema: `{platform.platform()}`. Hardware: `{json.dumps(hardware,ensure_ascii=False)}`.',
           'Entorno: `.venv-repro/`. Precisión de los certificados: 256 bits, comprobada en cada salida.',
           'Comando de cálculo: `./run_certificates.sh 8`, con ocho procesos. El ejecutable python3 del PATH registra tiempos y ejecuta el Python del entorno; no modifica los programas de certificación.',
           'Los 25 certificados y 38 archivos adicionales del ZIP adjunto coinciden byte a byte con el commit; el TEX adjunto y el ZIP completo también coinciden. CRC del ZIP correcto.',
           'Cada certificado se compara íntegramente tras excluir solamente la línea de versión de Python y los tiempos. Esto incluye cotas, inclusiones, radios, límites, cuentas de cajas/intervalos y procedencia SHA-256.',
           'Los SHA-256 completos de salida pueden cambiar por la versión de Python y los tiempos; se conservan ambos hashes y el diff completo. Los hashes de datos y programas deben coincidir exactamente.',
           'La reproducción verifica estos cálculos finitos y las constantes derivadas; no constituye una nueva evaluación de todas las demostraciones analíticas del manuscrito.','',
           '| Certificado | Veredicto | Cota | Cajas (+/−/cola) o intervalos | Tiempo publicado (s) | Tiempo certificado Mac (s) | Pared Mac (s) | Diferencias matemáticas |',
           '|---|---|---|---|---:|---:|---:|---|']
    for rel,row in rows.items():
        st=row.get('reproduced',row['published']); boxes='/'.join(st['boxes']) or '/'.join(st['intervals']) or '—'
        wall=row.get('wall_seconds'); wall=f'{wall:.3f}' if wall is not None else '—'
        lines.append(f"| `{rel}` | {row['status']} | {', '.join(st['bound'])} | {boxes} | {row['published']['seconds']} | {row.get('reproduced',{}).get('seconds','—')} | {wall} | {row.get('mathematical_diff','pendiente')} |")
    lines += ['','## Constantes de las seis rectas','',
              '| Recta | A1 publicado / reproducido | A3_N publicado / reproducido | A3_S publicado / reproducido | Veredicto |','|---|---|---|---|---|']
    for tag in TAGS:
        old=json.loads((E/'baseline'/f'family/line_{tag}/summary_pp.json').read_text()); new=state['line_constants'].get(tag,{})
        lines.append('| '+tag+' | '+' | '.join(f"{old[k]} / {new.get(k,'pendiente')}" for k in ['A1','A3_N','A3_S'])+' | '+new.get('verdict','PENDIENTE')+' |')
    lines += ['','## Hashes SHA-256 de las salidas','',
              '| Certificado | Publicado | Reproducido | Contenido normalizado idéntico |','|---|---|---|---|']
    for rel,row in rows.items():lines.append(f"| `{rel}` | `{row['published_sha256']}` | `{row.get('reproduced_sha256','pendiente')}` | {row.get('canonical_equal','pendiente')} |")
    lines += ['','## Evidencia y adaptación local','',
              'Los certificados publicados, datos, resúmenes y programas previos se conservan en `repro_evidence_2026-11-01/baseline/`, con manifiesto SHA-256; los resultados independientes se conservan en `reproduced/`.',
              'Metadatos, versiones, hashes de las fuentes adjuntas, tiempos por invocación, verificaciones y diferencias están en `repro_evidence_2026-11-01/`.',
              'El `finalize.py` publicado usa `/home/claude/papermath/.../family/`; la única adaptación prevista es sustituirla por la ruta al directorio family de este clon. Se conserva el original y el diff. No se ejecuta ningún generador del manuscrito.',
              f"Estado de finalización: {state.get('finalize','pendiente')}. Tiempo transcurrido total: {time.monotonic()-run_start:.3f} s.",
              'No se hacen commits ni se crea una versión v10.']
    if state['discrepancies']:lines+=['','## Incidencias','']+state['discrepancies']
    if state.get('integrity'):lines+=['','## Integridad final','',json.dumps(state['integrity'],ensure_ascii=False)]
    tmp=REPORT.with_suffix('.md.tmp');tmp.write_text('\n'.join(lines)+'\n');tmp.replace(REPORT)

def check_certificate(rel,event):
    p=BASE/(rel+'.new'); text=p.read_text()
    if MARKERS[p.name.removesuffix('.new')] not in text:raise RuntimeError('Certificado sin marca final: '+rel)
    prov=hashes(text,rel)
    if 'python-flint 0.9.0, precision 256 bits' not in text:raise RuntimeError('Entorno/precisión distintos: '+rel)
    original=(E/'baseline'/rel).read_text(); equal=canonical(text)==canonical(original)
    row=rows[rel];row.update(reproduced_sha256=sha(p.read_bytes()),reproduced=stats(text),canonical_equal=equal,
                             wall_seconds=event['seconds'],mathematical_diff='ninguna' if equal else 'DETECTADA')
    dest=E/'reproduced'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    diff=''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='published/'+rel,tofile='reproduced/'+rel))
    dp=E/'diffs'/(rel+'.diff');dp.parent.mkdir(parents=True,exist_ok=True);dp.write_text(diff)
    if not equal:
        row['status']='DISCREPANCIA'; raise RuntimeError('Diferencia en contenido matemático: '+rel+'; ver '+str(dp))
    if prov!=row['provenance']:raise RuntimeError('Procedencia distinta: '+rel)
    row['status']='REPRODUCIDO'
    print('VERIFIED',rel,'wall',round(event['seconds'],3),'s',flush=True)

report()
env=os.environ.copy();env['PATH']=str(E/'bin')+':'+str(ROOT/'.venv-repro/bin')+':'+env.get('PATH','');env['PYTHONUNBUFFERED']='1'
env['OPENBLAS_NUM_THREADS']='1';env['OMP_NUM_THREADS']='1';env['VECLIB_MAXIMUM_THREADS']='1'
(E/'bin').mkdir();shutil.copy2('/private/tmp/papermath-order6/python3',E/'bin/python3');(E/'bin/python3').chmod(0o755)
log=open(E/'run_certificates.log','w',buffering=1)
proc=subprocess.Popen(['./run_certificates.sh','8'],cwd=BASE,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
state['pid']=proc.pid;state['process_group']=proc.pid;report()
seen=set()
try:
    while True:
        events=[]
        for p in sorted((E/'events').glob('*.json')):
            if p.name not in seen:events.append((p,json.loads(p.read_text())))
        for p,event in events:
            seen.add(p.name);args=event['args']
            if not args or args[0]=='-c':continue
            fn=Path(args[0]).name
            if fn=='certify_hybrid.py':
                rel='hybrid_asymptotic/cert_m10P.txt' if args[1]=='hyb_m10_P.json' else 'family/'+str(Path(args[1]).parent)+'/cert_kernel.txt'
                if event['returncode'] and args[1]!='hyb_m10_P.json' and args[2]=='100':
                    state.setdefault('retries',[]).append(event);continue
            elif fn=='cz_gen_pp.py':rel='family/'+str(Path(args[1]).parent)+'/cert_czeta_pp.txt'
            elif fn=='elem_gen.py':rel='family/'+str(Path(args[1]).parent)+('/cert_elem.txt' if args[-1]=='N' else '/cert_elem_S.txt')
            else:raise RuntimeError('Invocación no prevista: '+str(args))
            if event['returncode']:raise RuntimeError('Proceso fallido: '+str(event))
            check_certificate(rel,event);report()
        if proc.poll() is not None:
            # Event files are atomically committed before each wrapper exits.
            pending={p.name for p in (E/'events').glob('*.json')}-seen
            if pending:continue
            break
        time.sleep(2)
    if proc.returncode:raise RuntimeError('run_certificates.sh falló: '+str(proc.returncode))
    assert all(row['status']=='REPRODUCIDO' for row in rows.values()),'Faltan certificados'
    # Independently verify all auxiliary JSON outputs and all six constants before finalize mutates local copies.
    sys.path.insert(0,str(BASE/'hybrid_asymptotic'))
    from certutil import A,up_str
    for tag in TAGS:
        folder=BASE/f'family/line_{tag}'
        for fn in ['sol_czpp.json','sol_elem.json','sol_elemS.json']:
            old=json.loads((E/'baseline'/f'family/line_{tag}'/fn).read_text());new=json.loads((folder/fn).read_text())
            assert old==new,('JSON distinto',tag,fn,old,new)
        old=json.loads((E/'baseline'/f'family/line_{tag}/summary_pp.json').read_text())
        sol=json.loads((folder/'sol.json').read_text()); c1=A(Fraction(sol['c'][0]))/(2*flint.arb.pi())
        with localcontext() as ctx:
            ctx.prec=100
            a1=str(Decimal(up_str(c1,80)).quantize(Decimal('0.00001'),rounding=ROUND_CEILING))
            cz=Decimal(json.loads((folder/'sol_czpp.json').read_text())['Czeta_upper'])
            fn=Decimal(json.loads((folder/'sol_elem.json').read_text())['Fsup_upper'])
            fs=Decimal(json.loads((folder/'sol_elemS.json').read_text())['Fsup_upper'])
            an=str((cz+fn).quantize(Decimal('0.001'),rounding=ROUND_CEILING))
            ass=str((cz+fs).quantize(Decimal('0.001'),rounding=ROUND_CEILING))
        assert A(Fraction(a1))>=c1
        assert {'A1':a1,'A3_N':an,'A3_S':ass}=={k:old[k] for k in ['A1','A3_N','A3_S']},('Constantes distintas',tag)
        state['line_constants'][tag]={'A1':a1,'A3_N':an,'A3_S':ass,'C1_enclosure':c1.str(70),'verdict':'REPRODUCIDO'}
    state['phase']='25/25 VERIFICADOS; FINALIZANDO';report()
    finalize=BASE/'rerun/finalize.py';old=finalize.read_text()
    hardcoded="FAM = '/home/claude/papermath/numerics/explicit_S_turing/family/'"
    assert old.count(hardcoded)==1
    new=old.replace(hardcoded,'FAM = '+repr(str(BASE/'family')+'/'))
    finalize.write_text(new)
    (E/'finalize_path.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='published/finalize.py',tofile='Mac-reproduction/finalize.py')))
    fstart=time.monotonic()
    with open(E/'finalize.log','w') as f:
        ret=subprocess.run(['python3','rerun/finalize.py'],cwd=BASE,env={**env,'PATH':str(ROOT/'.venv-repro/bin')+':'+os.environ.get('PATH','')},stdout=f,stderr=subprocess.STDOUT)
    assert ret.returncode==0,(E/'finalize.log').read_text()
    assert 'finalize ok' in (E/'finalize.log').read_text()
    state['finalize']={'returncode':ret.returncode,'seconds':time.monotonic()-fstart,'cwd':str(BASE),'path_only_adaptation':True}
    shutil.move(BASE/'hybrid_asymptotic/cert_m10P.txt.new',BASE/'hybrid_asymptotic/cert_m10P.txt')
    for tag in TAGS:
        rel=f'family/line_{tag}/summary_pp.json'
        assert json.loads((BASE/rel).read_text())==json.loads((E/'baseline'/rel).read_text())
    allowed=set(CERTS)|{'rerun/finalize.py'}
    changed=[]
    for rel,h in baseline.items():
        actual=sha((BASE/rel).read_bytes())
        if actual!=h:changed.append(rel)
        if rel not in allowed:assert actual==h,('Archivo protegido modificado',rel)
    for rel,row in rows.items():assert sha((BASE/rel).read_bytes())==row['reproduced_sha256']
    for p in [zpath,tpath]:assert sha(p.read_bytes())==supplied[str(p)]['sha256']
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==commit
    state['integrity']={'tracked_numerics_files':len(baseline),'changed_in_reproduction_clone':changed,
                        'all_other_files_unchanged':True,'manuscript_unchanged':True,'supplied_files_unchanged':True,
                        'baseline_sha256_verified':all(sha((E/'baseline'/rel).read_bytes())==h for rel,h in baseline.items()),
                        'no_commit_created':True}
    (E/'git_status_final.txt').write_text(subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True))
    state['phase']='REPRODUCCIÓN CONFORME — 25/25; SEIS RECTAS CONFORMES';state['finished']=now();report()
    print(state['phase'],str(REPORT),flush=True)
except BaseException as exc:
    if proc.poll() is None:
        os.killpg(proc.pid,signal.SIGTERM)
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait()
    state['phase']='DETENIDA — REQUIERE EXAMEN';state['discrepancies'].append(repr(exc));state['finished']=now();report()
    print('STOPPED',repr(exc),flush=True)
    raise
finally:
    log.close()
